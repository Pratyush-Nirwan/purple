module.exports = {
    name: 'pulse',
    cooldown: 10,
    description:"check the pulse of the general chat!",
    execute(message, args, client, Discord){
        if(message.channel.id !== '788872012884869181' ){
            message.delete();
            return;
        }
        if(pulse >= 100){
            let embed = new Discord.MessageEmbed()
	.setColor('#2F3136')
	.setTitle('<:heartfull:824334201826181140><:heartfull:824334201826181140><:heartfull:824334201826181140>')
	.setDescription("Nice work guys <#788872012884869181>'s pulse is **"+pulse+"** right now!:grinning:")
    message.channel.send({embeds:[embed]});
        }
        if(100 >= pulse >= 5){
            let embed = new Discord.MessageEmbed()
	.setColor('#2F3136')
	.setTitle('<:heartfull:824334201826181140><:heartfull:824334201826181140><:heartempty:824334239481987122>')
	.setDescription("Right now the pulse is **"+pulse+"** please dont let it go down, we dont want to lose <#788872012884869181>!:worried:")
    message.channel.send({embeds:[embed]});
        }
        if(5>= pulse >0){
			let embed = new Discord.MessageEmbed()
	.setColor('#2F3136')
	.setTitle('<:heartfull:824334201826181140><:heartempty:824334239481987122><:heartempty:824334239481987122>')
	.setDescription("Please guys we are gonna lose <#788872012884869181> if we dont talk in it. Please save it!:scream:\nPulse:**"+pulse+"**")
	message.channel.send({embeds:[embed]});
        }
        if(pulse === 0){
		return;
        }
 }
}
