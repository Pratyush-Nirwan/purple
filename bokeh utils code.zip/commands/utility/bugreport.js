module.exports = {
    name: 'bugreport',
    cooldown: 10,
    description:"send a bug report for the bot.",
    usage: '<bug>',
   async execute(message, args, client, Discord){
        const bugreportChannel = message.guild.channels.cache.get("813787134326341712");
        var bug = args.slice(0).join(" ");
        if(!bug) return message.channel.send({content:'Please provide a bug\nUsage: `b!bugreport <bug>`'});
        let username = message.author.tag;
        let embed = new Discord.MessageEmbed()
	.setColor('#2F3136')
	.setTitle(username+"'s Bug report:-")
    .setDescription("```"+bug+"```")   
        message.delete();
		bugreportChannel.send({embeds:[embed]}).then(sentEmbed => {
            sentEmbed.react("✅")
            sentEmbed.react("❌")
       
       let bugUrl = sentEmbed.url;
 
       let dmEmbed = new Discord.MessageEmbed()
	.setColor('#2F3136')
	.setTitle('Bug report submitted!')
    .setDescription("Your bug report has been submitted succesfully.\nBug:-\n```"+bug+"```\n You can check it out **[Here]("+bugUrl+")**") 
		message.author.send({embeds:[dmEmbed]});
        });
    }
}
