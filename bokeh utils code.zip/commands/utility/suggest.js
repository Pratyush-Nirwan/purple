module.exports = {
    name: 'suggest',
    cooldown: 10,
    description:"suggest stuff for the server.",
    usage: '',
   async execute(message, args, client, Discord){
    const suggestionsChannel = message.guild.channels.cache.get("807254114777432075");
    var suggestion = args.slice(0).join(" ");
    if (!suggestion) return message.channel.send({ content: 'Please provide a suggestion\nUsage: `b!suggest <your suggestion>`' })
    let embed = new Discord.MessageEmbed()
        .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic: true }))
        .setColor('#FFFF00')
        .setTitle('Suggested :-')
        .setDescription("```" + suggestion + "```")
        .addFields(
            { name: '**Status:-**', value: "PENDING" },
        )
    suggestionsChannel.send({ embeds: [embed] }).then(sentEmbed => {
        let editEmbed = new Discord.MessageEmbed()
        .setAuthor(message.author.tag, message.author.displayAvatarURL({ dynamic: true }))
        .setColor('#FFFF00')
        .setTitle('Suggested :-')
        .setDescription("```" + suggestion + "```")
        .addFields(
            { name: `**ID:-**`, value: `\`${sentEmbed.id}\``, inline: true}
        )
        .addFields(
            { name: '**Status:-**', value: "PENDING" ,inline: true },
        )
        sentEmbed.edit({embeds: [editEmbed]})

        sentEmbed.react("✅")
        sentEmbed.react("❌")
        let suggestionUrl = sentEmbed.url;

        let dmEmbed = new Discord.MessageEmbed()
            .setColor('#2F3136')
            .setTitle('Suggestion submitted!')
            .setDescription("Your suggestion has been submitted succesfully.\nYou can check it out **[Here](" + suggestionUrl + ")**")
        message.reply({ embeds: [dmEmbed] });
    });
    }
}
