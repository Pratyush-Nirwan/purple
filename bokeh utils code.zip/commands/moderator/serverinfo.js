const { MessageButton, MessageActionRow } = require('discord.js');
const { DiscordAPIError } = require('discord.js');
module.exports = {
    name: 'serverinfo',
    execute(message, args, client, Discord) {
        if (!message.member.roles.cache.has('776109191181893673')) return message.delete();
        message.delete();

        let ad = "```***Hello! Seeking a place to show your Photography skills and share your thoughts?***\n\n__**Photographers Support**__ is all about collaborating, sharing, conversation, and more! We have a wide variety of topics however we’re always listening to suggestions from the community!\n:relieved:***A place to chill with others and relax.***\n:camera: ***Share your photos and videos!***\n:star: ***Promote your posts from different social media sites.***\n:musical_note: ***Who doesn't love music!***\n:gear: ***We have a custom made photographers utility bot and a music bot.***\n:robot: ***Bots are at your service.***\n:joy: ***Fun and enjoyment!***\n:heart: ***And much more!!***\n\n**JOIN NOW!!**\nGraphics link:- https://imgur.com/d6ZCeRl\nInvite:- https://discord.gg/rUrH3fpMFU ```";


        let website = new MessageButton()
            .setStyle('LINK')
            .setLabel('🌐Our Website')
            .setURL('http://www.psdiscord.rf.gd/');

        let review = new MessageButton()
            .setStyle('LINK')
            .setLabel('💓Leave a review')
            .setURL('https://disboard.org/review/create/776107860694007808');

        let serverStats = new MessageButton()
            .setStyle('LINK')
            .setLabel('📊Sever Stats')
            .setURL('https://statbot.net/dashboard/776107860694007808/');

        let row = new MessageActionRow()
            .addComponents(website, review, serverStats)

        let adEmbed = new Discord.MessageEmbed()
            .setTitle('📌Our advertisement')
            .setColor('#2F3136');
        let linkEmbed = new Discord.MessageEmbed()
            .setTitle('📌Important Links related to us')
            .setColor('#2F3136');
            message.channel.send({embeds: [adEmbed]})
            message.channel.send({ content: `${ad}`})
            message.channel.send({ components: [row], embeds: [linkEmbed]})

    }
}