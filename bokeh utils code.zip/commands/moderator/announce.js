module.exports = {
    name: 'announce',
    cooldown: 5,
    description:"This is send announcement in the announcements channel.",
    usage: '<announcement>',
   async execute(message, args, client, Discord){
    if(!message.member.roles.cache.has('776109191181893673')||!message.member.roles.cache.has('806113107235569664')||!message.member.roles.cache.has('776110194266210354')) return message.delete();
        const announcementChannel = message.guild.channels.cache.get("776107860694007811");
        const announcementPing = message.guild.roles.cache.get("789478859514314813");
        var announcement = args.slice(0).join(" ");
        let embed = new Discord.MessageEmbed()
	.setColor('#2F3136')
    .setDescription(`${announcement}`)
    .setTimestamp(); 
        message.delete();
        announcementChannel.send({content : announcementPing, embeds:[embed]})
		.then(msg => {
            msg.react(message.guild.emojis.cache.random().id);
            msg.react(message.guild.emojis.cache.random().id);
            msg.react(message.guild.emojis.cache.random().id);
            msg.react(message.guild.emojis.cache.random().id);
            msg.react(message.guild.emojis.cache.random().id);
            msg.react(message.guild.emojis.cache.random().id);
            msg.react(message.guild.emojis.cache.random().id);
            msg.react(message.guild.emojis.cache.random().id);
            msg.react(message.guild.emojis.cache.random().id);
            msg.react(message.guild.emojis.cache.random().id);
        })
    }
}
