module.exports = {
    name: 'accept',
    description:"This accepts the suggestion",
    usage: '<bot/server> <suggestion message ID> <reason>',
    async execute(message, args, client, Discord){
        const suggestionID = args[0];
        const reason = args.slice(1).join(" ");
          if(!message.member.roles.cache.has('806113107235569664')||!message.member.roles.cache.has('776110194266210354')) return message.delete();
            const suggestionChannel =  message.guild.channels.cache.get("807254114777432075");
            const suggestionMsg = await suggestionChannel.messages.fetch(suggestionID);

            const embedData = suggestionMsg.embeds[0];
            let editEmbed = new Discord.MessageEmbed()
            .setAuthor(embedData.author.name, embedData.author.iconURL)
            .setColor('#2ECC71')
            .setTitle(embedData.title)
            .setDescription(embedData.description)   
            .addFields(
                { name: '**Status**', value: "ACCEPTED"},
                { name: 'Reason:-', value:`${reason}`},
          )                 
          suggestionMsg.edit(editEmbed).then(sentEmbed => {
            let msgUrl = sentEmbed.url;  
          let dmEmbed = new Discord.MessageEmbed()
          .setColor('#2F3136')
          .setTitle('Server suggestion Accepted!')
          .setDescription("Your suggestion has been Accepted\nSuggestion:-\n"+embedData.description+"\n You can check it out **[Here]("+msgUrl+")**")
          const suggestionAuthor = client.users.cache.find((u)=>u.tag === embedData.author.name);
          suggestionAuthor.send({embeds: [dmEmbed]})
          })

          message.channel.reply({content : `Accepted 🟢`});
          return;
        
    }
}