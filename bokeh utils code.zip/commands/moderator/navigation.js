module.exports = {
    name: 'navigation',
    description:"This sends the navigation thingy.",
    execute(message, args, client, Discord){
        if(message.author.id !== '727559089835737150') return message.delete();
        const nav = new Discord.MessageEmbed()
        .setColor('#2F3136')
        .setDescription("**These are the most used channels**\n\n<#788872012884869181> - A general chat.\n<#793142905727352852> - A place to talk about photography experiences!\n<#776384176001777691> - Share your photos here.\n<#776384220267413537> - Share your videos here.\n<#824684945250975774> - A place where you can self-promote (Requires level 1+).\n<#776140199829831733> - The rules and frequently asked questions!\n<#789101400654217236> - View the servers that are partnered with us!\n<#808305970030968873> - A place where you can create a ticket and ask for help.")
        
        const nav2 = new Discord.MessageEmbed()
        .setColor('#2F3136')
        .setDescription('**These are the channels where you can ask for help and share your photos or videos related to a particular topic.**\n\n<#776476180487471144>\n<#776479186306465834>\n<#776479615862439957>\n<#809827359687442442>\n<#776479768216469534>\n<#843782418569101332>\n<#776486994129322004>\n<#776479946637967380>\n<#776480085141356574>\n<#776480270760804372>\n<#776480406291349524>\n<#820519497822765077>\n<#850007510563946506>')
        message.delete()
        message.channel.send({content: 'https://i.imgur.com/q8nX240.png'})
        message.channel.send({embeds:[nav,nav2]})
    }
}