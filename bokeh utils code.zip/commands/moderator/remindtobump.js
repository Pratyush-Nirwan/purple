const ms = require('ms')
const db = require('quick.db')
const bump = require('../../functions/bump')
module.exports = {
    name: 'remindtobump',
    description: 'Resets the bump timer',
    usage: '<time>',
    execute(message, args, client, Discord) {
        if (!message.member.roles.cache.has('806113107235569664') || !message.member.roles.cache.has('776110194266210354')) return message.delete();
        const interval = ms(args[0]);
        const time = ms(interval, { long: true })
        const embed = new Discord.MessageEmbed()
        .setColor('#2F3136')
        .setDescription(`OK, I will remind to bump the server in ${time}.⏳`)

        message.reply({embeds:[embed]})
        setTimeout(() => {
            db.set('isReminded', 'true');
            db.set('isBumped', 'false');
            bump.execute(message, client, Discord);
        }, interval);

        
    }
}