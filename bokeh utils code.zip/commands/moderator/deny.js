module.exports = {
    name: 'deny',
    description:"This denies the suggestion",
    usage: '<bot/server> <suggestion message ID> <reason>',
    async execute(message, args, client, Discord){
       
        const suggestionType = args[0];
        const suggestionID = args[1];
        const reason = args.slice(2).join(" ");

        if(suggestionType.toLowerCase() === 'bot'){
          const suggestionChannel =  message.guild.channels.cache.get("813785466885242910");
            const suggestionMsg = await suggestionChannel.messages.fetch(suggestionID);

            const embedData = suggestionMsg.embeds[0];
            let editEmbed = new Discord.MessageEmbed()
            .setAuthor(embedData.author.name, embedData.author.iconURL)
            .setColor('#E74C3C')
            .setTitle(embedData.title)
            .setDescription(embedData.description)   
            .addFields(
                { name: '**Status**', value: "DENIED"},
                { name: 'Reason', value:`${reason}`},
          )                 
          suggestionMsg.edit(editEmbed).then(sentEmbed => {
            let msgUrl = sentEmbed.url;  
          let dmEmbed = new Discord.MessageEmbed()
          .setColor('#2F3136')
          .setTitle('Bot suggestion Denied!')
          .setDescription("Your suggestion has been Denied\nSuggestion:-\n"+embedData.description+"\n You can check it out **[Here]("+msgUrl+")**")
          const suggestionAuthor = client.users.cache.find((u)=>u.tag === embedData.author.name);
          suggestionAuthor.send({embeds: [dmEmbed]})
          })
          message.channel.send({ content: `Denied 🔴`})
          return;
        } 
        if(suggestionType.toLowerCase() === 'server'){
          if(!message.member.roles.cache.has('806113107235569664')||!message.member.roles.cache.has('776110194266210354')) return message.delete();
            const suggestionChannel =  message.guild.channels.cache.get("807254114777432075");
            const suggestionMsg = await suggestionChannel.messages.fetch(suggestionID);

            const embedData = suggestionMsg.embeds[0];
            let editEmbed = new Discord.MessageEmbed()
            .setAuthor(embedData.author.name, embedData.author.iconURL)
            .setColor('#E74C3C')
            .setTitle(embedData.title)
            .setDescription(embedData.description)   
            .addFields(
                { name: '**Status**', value: "DENIED"},
                { name: 'Reason:-', value:`${reason}`},
          )                 
          suggestionMsg.edit(editEmbed).then(sentEmbed => {
            let msgUrl = sentEmbed.url;  
          let dmEmbed = new Discord.MessageEmbed()
          .setColor('#2F3136')
          .setTitle('Server suggestion Denied!')
          .setDescription("Your suggestion has been Denied\nSuggestion:-\n"+embedData.description+"\n You can check it out **[Here]("+msgUrl+")**")
          const suggestionAuthor = client.users.cache.find((u)=>u.tag === embedData.author.name);
          suggestionAuthor.send({embeds: [dmEmbed]})
          })
          message.channel.send({ content: `Denied 🔴`})
          return;
        } else {
          message.channel.send({ content: 'Please enter a valid format, usage:- `b!deny <bot/server> <suggestionID> <reason>`'})
            return;
        }
    }
}