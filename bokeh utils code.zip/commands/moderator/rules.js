module.exports = {
  name: 'rules',
  description: "This is sends the server rules.",
  execute(message, args, client, Discord) {
    if (message.member.roles.cache.has('776109191181893673')) {
      message.delete();
      let rules = new Discord.MessageEmbed()
        .setColor('#2F3136')
        .setTitle('**🚨Rules**')
        .addFields(
          { name: 'Please read Discord TOS and Community Guidelines', value: "https://discord.com/terms\nhttps://discord.com/guidelines" },
        )
        .addFields(
          { name: '**\n🛡RULE 1**', value: "```Utilize common decency when interacting with 𝙢𝙚𝙢𝙗𝙚𝙧𝙨 𝙖𝙣𝙙 𝙨𝙩𝙖𝙛𝙛.```" },
          { name: '**\n🛡RULE 2**', value: "```Refrain from using languages other than 𝙀𝙣𝙜𝙡𝙞𝙨𝙝.```" },
          { name: '**\n🛡RULE 3**', value: "```If you happen to get into an 𝙖𝙧𝙜𝙪𝙢𝙚𝙣𝙩 please take it into 𝘿𝙈𝙨 so other members can have a pleasant experience.```" },
          { name: '**\n🛡RULE 4**', value: "```Sending content that 𝙞𝙨𝙣'𝙩 𝙮𝙤𝙪𝙧𝙨 without writing a disclaimer, isn't permitted.```" },
          { name: '**\n🛡RULE 5**', value: "```Send content in the 𝙘𝙤𝙧𝙧𝙚𝙘𝙩 𝙘𝙝𝙖𝙣𝙣𝙚𝙡𝙨 (read channel descriptions).```" },
          { name: '**\n🛡RULE 6**', value: "```Threats to other users of 𝘿𝘿𝙤𝙎, 𝘿𝙚𝙖𝙩𝙝, 𝘿𝙤𝙓, 𝙖𝙗𝙪𝙨𝙚, 𝙖𝙣𝙙 𝙤𝙩𝙝𝙚𝙧 𝙢𝙖𝙡𝙞𝙘𝙞𝙤𝙪𝙨 𝙩𝙝𝙧𝙚𝙖𝙩𝙨 are 𝙖𝙗𝙨𝙤𝙡𝙪𝙩𝙚𝙡𝙮 𝙥𝙧𝙤𝙝𝙞𝙗𝙞𝙩𝙚𝙙 and disallowed.```" },
          { name: '**\n🛡RULE 7**', value: "```𝙊𝙛𝙛𝙚𝙣𝙨𝙞𝙫𝙚 names and profile pictures are not allowed.(the mods will change your nickname without warning.)```" },
          { name: '**\n🛡RULE 8**', value: "```𝙍𝙖𝙞𝙙𝙞𝙣𝙜 or mentions of 𝙧𝙖𝙞𝙙𝙞𝙣𝙜 𝙤𝙩𝙝𝙚𝙧 𝙨𝙚𝙧𝙫𝙚𝙧𝙨 are not allowed.```" },
          { name: '**\n🛡RULE 9**', value: "```𝘿𝙤 𝙣𝙤𝙩 join voice chat channels without permission of the people already in there.```" },
          { name: '**\n🛡RULE 10**', value: "```If your name is hard to ping, e.g has off keyboard characters in the start moderators will 𝙘𝙝𝙖𝙣𝙜𝙚 𝙮𝙤𝙪𝙧 𝙣𝙞𝙘𝙠𝙣𝙖𝙢𝙚 to a easily mentionable one.```" },
          { name: '**\n🛡RULE 11**', value: "```𝘿𝙤 𝙣𝙤𝙩 mock or tease people based on the device, gear or software they use.```"},
          { name: '**\n🛡RULE 12**', value: "```𝘿𝙤 𝙣𝙤𝙩 steal try to steal the photos shared here, this is not a free stock photo platform.```"},
        )
      let punishment = new Discord.MessageEmbed()
        .setColor('#2F3136')
        .setTitle('**💀Punishments**')
        .setDescription('*Note: These punishments are for common rule infractions Mods can decide the punishment based on the serverity of the infraction.*')
        .addFields(
          { name: 'What can result in a warning?', value: "```•Abusing others.\n•Not keeping the chat appropiate.\n•Sending 𝙉𝙎𝙁𝙒 𝙞𝙢𝙖𝙜𝙚𝙨,𝙂𝙄𝙁𝙨 𝙤𝙧 𝙫𝙞𝙙𝙚𝙤𝙨\n•Provoking others to 𝙗𝙧𝙚𝙖𝙠 𝙧𝙪𝙡𝙚𝙨.\n•Hurting someone on purpose.```" },
          { name: "What can result in a mute?", value: "```•Doing the same thing again after reciving 𝙩𝙝𝙧𝙚𝙚 𝙬𝙖𝙧𝙣𝙞𝙣𝙜𝙨.\n•Doing arguments in the server.\n•Menitoning of raiding or nuking 𝙖𝙣𝙮 discord server.```" },
          { name: "What can result in a kick?", value: "```•Doing the same thing after reciving 𝙨𝙞𝙜𝙣𝙞𝙛𝙞𝙘𝙖𝙣𝙩 amount of mutes`.\n•Changing your nickname to an 𝙤𝙛𝙛𝙚𝙣𝙨𝙞𝙫𝙚 one or to one that makes it 𝙞𝙢𝙥𝙤𝙨𝙨𝙞𝙗𝙡𝙚 𝙩𝙤 𝙢𝙚𝙣𝙩𝙞𝙤𝙣 even after the mods have moderated it.\n•DM advertising.```" },
          { name: "What can result in a ban?", value: "```•Doing the same thing after rejoining after reciving a kick\n•Death threats\n•Sending content that 𝙞𝙨 𝙣𝙤𝙩 yours.\n•Being under 13 years old\n•Trying to or stealing photos. ```" },
        )

      let note = new Discord.MessageEmbed()
        .setColor('#2F3136')
        .setTitle('**📝Note**')
        .setDescription('***`•Your presence in the server means that you have read the rules and are accepting them.`***\n***`•Mods,Admins and Owner will take actions according to the situation.`***\n***`•Their decision is final.`***\n***`•If you think Mods,Admins or Owner have done something wrong please create a ticket in`*** <#808305970030968873>.')
        message.channel.send({content: 'https://i.imgur.com/uvEaCF1.png'})
        message.channel.send({embeds: [rules]})
        message.channel.send({content: 'https://i.imgur.com/HkdVGUy.png'})
        message.channel.send({embeds: [punishment]})
        message.channel.send({embeds: [note]})
    } else {
      message.delete();
      return;
    }
  }
}
