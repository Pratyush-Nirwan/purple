module.exports = {
    name: 'boostperks',
    description:"This is sends the booster perks.",
    execute(message, args, client, Discord){
         if(!message.member.roles.cache.has('776109191181893673')) return message.delete(); 
        message.delete();
        
        let perks = new Discord.MessageEmbed()
	.setColor('#2F3136')
	.setTitle('<a:NitroOP:817046453724774400>Booster Perks<a:NitroOP:817046453724774400>')
    .addFields(
        { name: '\u200b', value: `<a:nitro:817046401774387240>Access to every emoji in the server!!<:trolldog:792720597213773834>\n\n<a:nitro:817046401774387240>Get their name displayed separately.:star_struck: \n\n<a:nitro:817046401774387240>Get to create __**Two**__ custom roles for themselves.:partying_face:\n\n<a:nitro:817046401774387240>Ability to send images in <#788872012884869181>.:park: \n\n<a:nitro:817046401774387240> Get their social media profiles featured on our [website](https://psdiscord.wixsite.com/site).<:logo:793150049470119986>`},
    )
	.setFooter("The Photographer's support");
    message.channel.send({content : 'https://i.imgur.com/wQXYpAO.png'});
    message.channel.send({embeds:[perks]});
    }  
}