module.exports = {
  name: 'bump',
  description: "This is the bump reminder command.",
  execute(message, client, Discord) {
    let bumpChannel = client.channels.cache.get("796393370423525397");
    let bump = new Discord.MessageEmbed()
      .setColor('#2F3136')
      .setTitle('Disboard is off cooldown!')
      .setImage('https://i.imgur.com/KaJW3IK.png')
      .setDescription("Hey!! Disboard is off cool down! Lets bumps us using `!d bump`!!")
    console.log('reminding to bump now!')
    bumpChannel.send({content: `<@&793093176536858663>`, embeds:[bump]})
  }
}