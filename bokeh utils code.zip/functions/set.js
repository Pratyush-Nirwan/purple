const Levels = require("discord-xp");
module.exports = {
    name: 'set',
    description:"This is sets",
    async execute(message, target, level){
       var user = await Levels.fetch(target.id, message.guild.id);
    message.channel.send({content:`set ${target.tag}'s level to ${level}.`});
    }  
}