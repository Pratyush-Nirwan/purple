const fs = require('fs')
const moment = require('moment');
module.exports = {
    async execute(Discord, client , message){
        if(!message.guild || message.author.bot) return;

        const mentionMember = message.mentions.members.first();
    
        if(mentionMember){
            try{
                const data = fs.readFileSync(`./afk/${mentionMember.id}.txt`, 'utf8').split('\n');
                const timestamp = Number(data[1]);
                const reason = data[2];
                const timeAgo = moment(timestamp).fromNow();
                
                let embed = new Discord.MessageEmbed()
                .setDescription(`${mentionMember} is currently AFK🌙 (${timeAgo})\nReason: \`${reason}\``)
                .setColor('#2F3136')
                message.channel.send({content: `${message.author}`, embeds:[embed]})
                
            }
            catch(e){
                return;
            }
        }

        try{
            const getData = fs.readFileSync(`./afk/${message.author.id}.txt`, 'utf8').split('\n')
            if(getData){
                fs.unlinkSync(`./afk/${message.author.id}.txt`);
                const {guild} = message;
                const member = guild.members.cache.get(message.author.id); 
                const afkName = `${member.nickname}` || `${member.username}`;
                const reset = afkName.replace(`[AFK]`, '');
                if(message.author.id !== guild.ownerId ){
                    if(reset === message.author.username){
                        member.setNickname(null);
                        message.reply({content:`You are not AFK anymore!`});
                    } else {
                        member.setNickname(reset);
                        message.reply({content:`You are not AFK anymore!`});
                    }
                    
                } else {
                    message.reply({content:`You are not AFK anymore!`});
                }
            }
        }
        catch(e){
            return;
        }

    }  
}