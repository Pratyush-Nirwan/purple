const { chatBot } = require("reconlx");
module.exports = {
    async execute(message, client, Discord){
        if(!message.guild || message.author.bot) return;
        if(message.channel.id !== '845711567291285504') return;
        message.channel.startTyping(3000);
        setTimeout(() => {
            chatBot(message, message.content); 
        }, 3000)
        message.channel.stopTyping(true);
   }
}