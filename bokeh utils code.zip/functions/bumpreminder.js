const { deepStrictEqual } = require('assert');
const fs = require('fs')
const db = require('quick.db')
const bumpjs = require('../functions/bump');
module.exports = {
    async execute(message, client, Discord){
        if(message.content.toLowerCase() === "!d bump"){
            if(message.channel.id !== '796393370423525397'){
                message.reply('Please only bump the server in <#796393370423525397>')
                return;
            }
            const dbump = db.get('isBumped')

            if(dbump === 'true') return message.reply({content:"Sorry! Someone has already bumped the server!"});
            db.set('isBumped', 'true')
            message.react('❤️');
            message.reply({content:'Thanks for bumping the server!!:heart:'});
            console.log('server bumped!!');
              const time = Date.now().toString();
              db.set('isReminded', 'false')
              db.set('bumpWhen', time)
              
          }
    }  
}