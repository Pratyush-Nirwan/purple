const remindToBump = require('./bump')
const fs = require('fs')
const db = require('quick.db')
module.exports = {
  async execute(message, client, Discord, timeNow) {
    try {
      const lastBumped = db.get('bumpWhen');
      const isReminded = db.get('isReminded');
      if (!lastBumped) {
        db.set('isReminded', 'true');
        remindToBump.execute(message, client, Discord);
        return;
      }

      if (parseInt(timeNow) - lastBumped >= 7200000 && isReminded === 'false') {
        db.set('isReminded', 'true');
        db.set('isBumped', 'false');
        remindToBump.execute(message, client, Discord);
        return;
      }
    }
    catch (err) {
      return;
    }
  }
}