const fs = require('fs');
let reply_data = fs.readFileSync("./replies.txt").toString();
let replies = reply_data.split("\n");

module.exports = async (client, Discord) => {
  setInterval(() => {
    const guild = client.guilds.cache.get("776107860694007808");
    let random = Math.floor(Math.random() * replies.length-1);
    client.channels.cache.get('788872012884869181').send({content:replies[random]});
  }, 28800000);
}
